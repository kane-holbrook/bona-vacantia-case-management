var resourceURL = '/resource/'
window.Core.forceBackendType('ems');

var documentViewer = instance.Core.documentViewer;

var urlSearch = new URLSearchParams(location.hash)
var custom = JSON.parse(urlSearch.get('custom'));
resourceURL = resourceURL + custom.namespacePrefix;

/**
 * The following `window.Core.set*` functions point WebViewer to the
 * optimized source code specific for the Salesforce platform, to ensure the
 * uploaded files stay under the 5mb limit
 */

// font workers
instance.UI.setFontPath('../../../..' + resourceURL + 'font_assets/fonts');

// office workers
window.Core.setOfficeWorkerPath(resourceURL + 'office')
window.Core.setOfficeAsmPath(resourceURL + 'office_asm');
window.Core.setOfficeResourcePath(resourceURL + 'office_resource');

//office editing
window.Core.setOfficeEditorWorkerPath(resourceURL + 'office_edit');

window.Core.ContentEdit.setWorkerPath(resourceURL + 'content_edit');
window.Core.ContentEdit.setResourcePath(resourceURL + 'content_edit_resource');

// pdf workers
window.Core.setPDFResourcePath(resourceURL + 'resource')
if (custom.fullAPI) {
  window.Core.setPDFWorkerPath(resourceURL + 'pdf_full');
} else {
  window.Core.setPDFWorkerPath(resourceURL + 'pdf_lean')
}

// external 3rd party libraries
window.Core.setExternalPath(resourceURL + 'external')

var currentDocId;

async function fillDocument(event) {
  const autofillMap = event.data.mapping;

  console.log('autofillMap', autofillMap);

  await documentViewer.getDocument().applyTemplateValues(autofillMap);
}


function _arrayBufferToBase64( buffer ) {
  var binary = '';
  var bytes = new Uint8Array( buffer );
  var len = bytes.byteLength;
  for (var i = 0; i < len; i++) {
      binary += String.fromCharCode( bytes[ i ] );
  }
  return window.btoa( binary );
}

async function generateBulkDocument(event){
  const autofillMap = event.data.results;
  

  console.log(autofillMap);
  const { blob, extension, filename, documentId } = currentDocId;
  const buffer = await blob.arrayBuffer();

  for(const e of autofillMap){
    console.log(e);

    let item = await Core.officeToPDFBuffer(buffer, {
      extension: extension,
      officeOptions: {
        templateValues: e 
      }});

    downloadFile(item, filename, extension)
    console.log(item);
  }

}

async function saveDocument() {
  // SF document file size limit
  const docLimit = 5 * Math.pow(1024, 2);
  const doc = instance.Core.documentViewer.getDocument();
  if (!doc) {
    return;
  }

  console.log('Valid document');
  instance.UI.openElement('loadingModal');
  const fileSize = await doc.getFileSize();
  const fileType = doc.getType();
  let filename = doc.getFilename();

  // Append .png to image files
  if (fileType == 'image'){
    filename = filename + '.png';
  }

  console.log(fileType);

  const downloadType = 'templateFilledOffice';

  console.log('Loaded everything else');
  const data = await doc.getFileData({
    // Saves the document with annotations in it
    downloadType,
    officeOptions: {
      finishedWithDocument: true
    }
  });

  console.log('Processed the file data');

  let binary = '';
  const bytes = new Uint8Array(data);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }

  const base64Data = window.btoa(binary);

  console.log('Before payload');

  const payload = {
    title: filename.replace(/\.[^/.]+$/, ""),
    filename,
    base64Data,
    contentDocumentId: currentDocId
  }

  console.log(payload);
  // Post message to LWC
  fileSize < docLimit ? parent.postMessage({ type: 'SAVE_SHAREPOINT_DOCUMENT', payload }, '*') : downloadWebViewerFile();
}

const downloadWebViewerFile = async () => {
  const doc = instance.Core.documentViewer.getDocument();

  if (!doc) {
    return;
  }

  const data = await doc.getFileData();
  const arr = new Uint8Array(data);
  const blob = new Blob([arr], { type: 'application/pdf' });

  const filename = doc.getFilename();

  downloadFile(blob, filename)
}

const downloadFile = (blob, fileName) => {
  const link = document.createElement('a');
  // create a blobURI pointing to our Blob
  link.href = URL.createObjectURL(blob);
  link.download = fileName;
  // some browser needs the anchor to be in the doc
  document.body.append(link);
  link.click();
  link.remove();
  // in case the Blob uses a lot of memory
  setTimeout(() => URL.revokeObjectURL(link.href), 7000);
};

window.addEventListener('viewerLoaded', async function () {
  /**
   * On keydown of either the button combination Ctrl+S or Cmd+S, invoke the
   * saveDocument function
   */
  instance.UI.hotkeys.on('ctrl+s, command+s', e => {
    e.preventDefault();
    saveDocument();
  });

  // Listen for the custom event to trigger saveDocument
  window.addEventListener('triggerSaveDocument', function() {
    saveDocument(); // Call saveDocument when the event is triggered
  });

  documentViewer.addEventListener('documentLoaded', async () => {
    console.log('document loaded!');

    instance.UI.setLayoutMode(instance.UI.LayoutMode.FacingContinuous)

    await Core.PDFNet.initialize();

    await documentViewer.getDocument();
    documentViewer.updateView();

    const doc = documentViewer.getDocument();
    const fileType = doc.getType();
    const keys = await doc.getTemplateKeys();

    if (fileType === 'officeEditor') {
      instance.UI.disableElement('saveDocumentButton');
    }

    console.log("keys", keys);

    parent.postMessage({ type: 'DOCUMENT_LOADED' }, '*');

    parent.postMessage({ type: 'DOC_KEYS', keys }, '*');
  })

  // // Create a button, with a disk icon, to invoke the saveDocument function
  // instance.UI.setHeaderItems(function (header) {
  //   var myCustomButton = {
  //     type: 'actionButton',
  //     dataElement: 'saveDocumentButton',
  //     title: 'tool.SaveDocument',
  //     img: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>',
  //     onClick: function () {
  //       saveDocument();
  //     }
  //   }
  //   header.get('viewControlsButton').insertBefore(myCustomButton);
  // });
});

async function convertToPdf(payload) {
  const { blob, extension, filename, documentId } = payload;
  currentDocId = documentId;

  try {
    // Load the DOCX document in WebViewer
    instance.UI.loadDocument(blob, { 
      extension,
      filename, 
      documentId
    });

    // Wait for the document to be fully loaded
    documentViewer.addEventListener('documentLoaded', async () => {
      const doc = instance.Core.documentViewer.getDocument();

      if (!doc) {
        return;
      }

      console.log('Document loaded, starting conversion...');

      // Export the annotations if any
      const xfdfString = await instance.Core.documentViewer.getAnnotationManager().exportAnnotations();

      // Get the document data as PDF
      const pdfBuffer = await doc.getFileData({ 
        xfdfString,
        downloadType: 'pdf' 
      });

      console.log('File data extracted');

      // Create a blob from the PDF buffer
      const pdfBlob = new Blob([new Uint8Array(pdfBuffer)], { type: 'application/pdf' });

      console.log('Blob converted to PDF');

      // Directly download the PDF file
      const pdfFilename = filename.replace(/\.docx$/, ".pdf");
      downloadFile(pdfBlob, pdfFilename);

      instance.UI.closeDocument();
      currentDocId = null;
    });
  } catch (error) {
    console.error('Error converting document to PDF:', error);
    parent.postMessage({ type: 'CONVERSION_ERROR', error: error.message }, '*');
  }
}

// Add this new helper function above mergePDFs
async function readDocumentContent(doc) {
  const PDFNet = Core.PDFNet;
  const pageReader = await PDFNet.ElementReader.create();
  const contentArray = [];

  try {
    const pageCount = await doc.getPageCount();
    
    for (let i = 1; i <= pageCount; i++) {
      const page = await doc.getPage(i);
      pageReader.beginOnPage(page);
      
      // Read page contents
      for (let element = await pageReader.next(); element !== null; element = await pageReader.next()) {
        const type = await element.getType();
        
        switch (type) {
          case PDFNet.Element.Type.e_text:
            const textData = await element.getTextString();
            contentArray.push({
              type: 'text',
              content: textData
            });
            break;
          case PDFNet.Element.Type.e_path:
            const pathData = await element.getPathData();
            contentArray.push({
              type: 'path',
              operators: pathData.operators,
              points: pathData.points
            });
            break;
          case PDFNet.Element.Type.e_form:
            pageReader.formBegin();
            // Recursively process form XObjects
            await readDocumentContent(doc);
            pageReader.end();
            break;
        }
      }
      pageReader.end();
    }
  } catch (error) {
    console.error('Error reading document content:', error);
    throw error;
  }
  
  return contentArray;
}

// Update the mergePDFs function to apply header content
async function mergePDFs(headerPdf) {
  try {
    console.log('Starting mergePDFs function');
    
    const doc = documentViewer.getDocument();
    if (!doc) {
      throw new Error('No document currently loaded');
    }

    const currentPdfData = await doc.getFileData({ downloadType: 'pdf' });
    
    // Convert documents to PDFDoc objects
    const headerArrayBuffer = await headerPdf.arrayBuffer();
    const headerDoc = await Core.PDFNet.PDFDoc.createFromBuffer(headerArrayBuffer);
    const currentDoc = await Core.PDFNet.PDFDoc.createFromBuffer(currentPdfData);

    try {
      // Read content from header document
      console.log('Reading header document content...');
      const headerContent = await readDocumentContent(headerDoc);
      console.log('Header content:', headerContent);

      const headerPage = await headerDoc.getPage(1);

      // Process the first page only
      const currentPage = await currentDoc.getPage(1);
      const currentBox = await currentPage.getCropBox();
      
      // Create elements for the page
      const builder = await Core.PDFNet.ElementBuilder.create();
      const writer = await Core.PDFNet.ElementWriter.create();
      await writer.beginOnPage(currentPage);

      // Process and write header content
      let xPos = currentBox.x1 + 50; // Start 50 units from left margin
      let yPos = currentBox.y2 - 50; // Start 50 units from top
      const lineHeight = 15; // Space between lines

      // Store color space + color point (used for text element)
      const colorspace = await Core.PDFNet.ColorSpace.createDeviceRGB();
      // Black
      const color = await Core.PDFNet.ColorPt.init(0, 0, 0, 0);

      for (const item of headerContent) {
        if (item.type === 'text') {
          builder.reset();

          let element;
          let gstate;

          // Create text element
          element = await builder.createTextBeginWithFont(await Core.PDFNet.Font.create(currentDoc, Core.PDFNet.Font.StandardType1Font.e_helvetica), 12);
          matrix = await Core.PDFNet.Matrix2D.create(1, 0, 0, 1, xPos, yPos);
          await writer.writeElement(element);

          element = await builder.createNewTextRun(item.content);
          element.setTextMatrix(matrix);
          gstate = await element.getGState();
          await gstate.setFillColorSpace(colorspace);
          await gstate.setFillColorWithColorPt(color);

          await writer.writeElement(element);
          
          // Move position for next text element
          xPos += (item.content.length * 7); // Approximate width per character
          
          // Move to next line if near right margin
          if (xPos > currentBox.x2 - 50) {
            xPos = currentBox.x1 + 50;
            yPos -= lineHeight;
          }
        }
      }

      writer.writeElement(await builder.createTextEnd());
      await writer.end();

      // Save and display the merged document
      const mergedData = await currentDoc.saveMemoryBuffer(
        Core.PDFNet.SDFDoc.SaveOptions.e_linearized
      );

      const mergedBlob = new Blob([new Uint8Array(mergedData)], { 
        type: 'application/pdf' 
      });

      await instance.UI.loadDocument(mergedBlob);
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      downloadFile(mergedBlob, 'merged_document.pdf');
      
      parent.postMessage({ type: 'PDF_MERGED', success: true }, '*');

    } finally {
      console.log('Everything ran fine');
    }

  } catch (error) {
    console.error('Detailed merge error:', error);
    console.error('Error stack:', error.stack);
    parent.postMessage({ 
      type: 'PDF_MERGED', 
      success: false, 
      error: error.message || 'Unknown error during merge' 
    }, '*');
  }
}

window.addEventListener("message", receiveMessage, false);

function receiveMessage(event) {
  if (event.isTrusted && typeof event.data === 'object') {
    switch (event.data.type) {
      case 'OPEN_DOCUMENT':
        instance.loadDocument(event.data.file)
        break;
      case 'OPEN_DOCUMENT_BLOB':
        const { blob, extension, filename, documentId } = event.data.payload;
        currentDocId = documentId;

        console.log("event.data.payload", event.data.payload);

        // Check if the document is a .docx file
        if (extension === 'docx') {
          // If so, enable office editing
          instance.UI.loadDocument(blob, { 
            extension,
            filename, 
            documentId, 
            officeOptions: {
              doTemplatePrep: true,
            },
          });
        } else {
          // For other file types, load normally
          instance.UI.loadDocument(blob, { 
            extension, 
            filename, 
            documentId,
          });
        };
        break;
      case 'DOCUMENT_SAVED':
        console.log(`${JSON.stringify(event.data)}`);
        instance.UI.openElements(['savedModal']);
        setTimeout(() => {
          instance.UI.closeElements(['savedModal', 'loadingModal'])
        }, 2000)
        break;
      case 'LMS_RECEIVED':  
        instance.loadDocument(event.data.payload.message, {
          filename: event.data.payload.filename,
          withCredentials: false
        });
        break;
      case 'FILL_TEMPLATE':
        fillDocument(event);
        break;
      case 'BULK_TEMPLATE':
        generateBulkDocument(event);
        break;
      case 'DOWNLOAD_DOCUMENT':
        downloadWebViewerFile();
        break;
      case 'CLOSE_DOCUMENT':
        instance.UI.closeDocument()
        currentDocId = null;
        break;
      case 'SAVE_DOCUMENT':
        saveDocument();  // Trigger saveDocument when the message is received
        break;
      case 'CONVERT_TO_PDF':
        convertToPdf(event.data.payload);
        break;
      case 'MERGE_PDF':
        mergePDFs(event.data.payload.headerPdf);
        event.data.payload.headerPdf
        break;
      default:
        break;
    }
  }
}