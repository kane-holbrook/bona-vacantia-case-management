var resourceURL = '/resource/'
window.Core.forceBackendType('ems');

var urlSearch = new URLSearchParams(location.hash)
var custom = JSON.parse(urlSearch.get('custom'));
resourceURL = resourceURL + custom.namespacePrefix;

/**
 * The following `window.Core.set*` functions point WebViewer to the
 * optimized source code specific for the Salesforce platform, to ensure the
 * uploaded files stay under the 5mb limit
 */
// office workers
window.Core.setOfficeWorkerPath(resourceURL + 'office')
window.Core.setOfficeAsmPath(resourceURL + 'office_asm');
window.Core.setOfficeResourcePath(resourceURL + 'office_resource');
window.Core.setOfficeEditorWorkerPath(resourceURL + 'office_edit');

// legacy office workers
window.Core.setLegacyOfficeWorkerPath(resourceURL + 'legacyOffice');
window.Core.setLegacyOfficeAsmPath(resourceURL + 'legacyOffice_asm');
window.Core.setLegacyOfficeResourcePath(resourceURL + 'legacyOffice_resource');

// pdf workers
window.Core.setPDFResourcePath(resourceURL + 'resource')
if (custom.fullAPI) {
  window.Core.setPDFWorkerPath(resourceURL + 'pdf_full')
  window.Core.setPDFAsmPath(resourceURL + 'asm_full');
} else {
  window.Core.setPDFWorkerPath(resourceURL + 'pdf_lean')
  window.Core.setPDFAsmPath(resourceURL + 'asm_lean');
}

// external 3rd party libraries
window.Core.setExternalPath(resourceURL + 'external')
window.Core.setCustomFontURL('https://pdftron.s3.amazonaws.com/custom/ID-zJWLuhTffd3c/vlocity/webfontsv20/');

var currentDocId;

async function fillDocument(event) {
  const { documentViewer } = instance.Core;
  const autofillMap = event.data.mapping;

  console.log('autofillMap', autofillMap);

  await documentViewer.getDocument().applyTemplateValues(autofillMap);
}


function _arrayBufferToBase64( buffer ) {
  var binary = '';
  var bytes = new Uint8Array( buffer );
  var len = bytes.byteLength;
  for (var i = 0; i < len; i++) {
      binary += String.fromCharCode( bytes[ i ] );
  }
  return window.btoa( binary );
}

function arrayBufferToBlob(arrayBuffer, type) {
  return new Blob([arrayBuffer], { type });
}

function normaliseDataFormat(data) {
  // If 'lookup' and 'template' are present, use the second format
  if (data.lookup && data.template) {
      try {
          const mappings = JSON.parse(data.template.Mapping__c);
          let normalisedData = { id: data.template.Id };

          // Use the mappings to set the correct key-value pairs
          for (const key in mappings) {
              if (mappings.hasOwnProperty(key)) {
                  // Assuming the values are in data.lookup
                  normalisedData[key] = data.lookup[mappings[key]];
              }
          }

          return normalisedData;
      } catch (error) {
          console.error("Error parsing Mapping__c field: ", error);
          throw error;
      }
  }
  // Otherwise, dynamically map all properties to the new object in the original format
  else {
      let normalisedData = {};
      for (const key in data) {
          if (data.hasOwnProperty(key)) {
              normalisedData[key] = data[key];
          }
      }
      return normalisedData;
  }
}

async function generateBulkDocument(event) {
  const { documentViewer } = instance.Core;

  // Check if event.data.results is an array
  let autofillMap;
  if (Array.isArray(event.data.results)) {
      autofillMap = event.data.results.map(normaliseDataFormat);
  } else {
      autofillMap = [normaliseDataFormat(event.data.results)];
  }

  console.log(autofillMap);
  const { blob, extension, filename, documentId } = currentDocId;
  const buffer = await blob.arrayBuffer();

  for(const e of autofillMap){
    console.log(e);

    let item = await Core.officeToPDFBuffer(buffer, {
      extension: extension,
      officeOptions: {
        templateValues: e 
      }});

      await documentViewer.getDocument().applyTemplateValues(autofillMap);

    console.log(item);

    // Convert the processed ArrayBuffer back to Blob
    const processedBlob = arrayBufferToBlob(item);

    // Modify the filename to have a .pdf extension
    let pdfFilename = filename.replace(/\.[^/.]+$/, "") + '.pdf';

    // Use the downloadFile function to download the Blob as a PDF
    downloadFile(processedBlob, pdfFilename);
  }
}

async function saveDocument(recordId) {
  // SF document file size limit
  const docLimit = 5 * Math.pow(1024, 2);
  const doc = instance.Core.documentViewer.getDocument();
  if (!doc) {
    return;
  }
  instance.UI.openElement('loadingModal');
  const fileSize = await doc.getFileSize();
  const fileType = doc.getType();
  let filename = doc.getFilename();

  // Append .png to image files
  if (fileType == 'image'){
    filename = filename + '.png';
  }

  console.log(fileType);

  const xfdfString = await instance.Core.documentViewer.getAnnotationManager().exportAnnotations();
  const downloadType = 'pdf';

  if (downloadType === 'pdf') {
    filename = filename.replace(/\.[^/.]+$/, "") + '.pdf';
  }
  const data = await doc.getFileData({
    // Saves the document with annotations in it
    xfdfString,
    downloadType
  });

  let binary = '';
  const bytes = new Uint8Array(data);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }

  const base64Data = window.btoa(binary);

  const payload = {
    title: filename.replace(/\.[^/.]+$/, ""),
    filename,
    base64Data,
    contentDocumentId: doc.__contentDocumentId,
    recordId
  }

  console.log(payload);
  // Post message to LWC
  fileSize < docLimit ? parent.postMessage({ type: 'SAVE_DOCUMENT', payload }, '*') : downloadWebViewerFile();
}

async function saveDocumentToSharePoint() {
  // SF document file size limit
  const docLimit = 5 * Math.pow(1024, 2);
  const doc = instance.Core.documentViewer.getDocument();
  if (!doc) {
    return;
  }
  instance.UI.openElement('loadingModal');
  const fileSize = await doc.getFileSize();
  const fileType = doc.getType();
  let filename = doc.getFilename();

  console.log('fileType' + fileType);

  const xfdfString = await instance.Core.documentViewer.getAnnotationManager().exportAnnotations();
  const downloadType = 'pdf';
  const data = await doc.getFileData({
    // Saves the document with annotations in it
    xfdfString,
    downloadType
  });

  let binary = '';
  const bytes = new Uint8Array(data);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }

  const base64Data = window.btoa(binary);

  const payload = {
    filename,
    base64Data
  }

  console.log(payload);
  // Post message to LWC
  fileSize < docLimit ? parent.postMessage({ type: 'SAVE_SHAREPOINT_DOCUMENT', payload }, '*') : downloadWebViewerFile();
}

const downloadWebViewerFile = async () => {
  const doc = instance.Core.documentViewer.getDocument();

  if (!doc) {
    return;
  }

  const data = await doc.getFileData();
  const arr = new Uint8Array(data);
  const blob = new Blob([arr], { type: 'application/pdf' });

  const filename = doc.getFilename();

  downloadFile(blob, filename)
}

const downloadFile = (blob, fileName) => {
  const link = document.createElement('a');
  // create a blobURI pointing to our Blob
  link.href = URL.createObjectURL(blob);
  link.download = fileName;
  // some browser needs the anchor to be in the doc
  document.body.append(link);
  link.click();
  link.remove();
  // in case the Blob uses a lot of memory
  setTimeout(() => URL.revokeObjectURL(link.href), 7000);
};

window.addEventListener('viewerLoaded', async function () {
  /**
   * On keydown of either the button combination Ctrl+S or Cmd+S, invoke the
   * saveDocument function
   */
  instance.UI.hotkeys.on('ctrl+s, command+s', e => {
    e.preventDefault();
    saveDocumentToSharePoint();
  });
  const { documentViewer } = instance.Core;

  documentViewer.addEventListener('documentLoaded', async () => {

    instance.UI.setLayoutMode(instance.UI.LayoutMode.FacingContinuous)

    await documentViewer.getDocument();
    documentViewer.updateView();

    const doc = documentViewer.getDocument();
    const fileType = doc.getType();
    const keys = await doc.getTemplateKeys();

    if (fileType === 'officeEditor') {
      instance.UI.disableElement('saveDocumentButton');
    }

    parent.postMessage({ type: 'DOC_KEYS', keys }, '*');
  })

  // Create a button, with a disk icon, to invoke the saveDocument function
  instance.UI.setHeaderItems(function (header) {
    var myCustomButton = {
      type: 'actionButton',
      dataElement: 'saveDocumentButton',
      title: 'tool.SaveDocument',
      img: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>',
      onClick: function () {
        saveDocumentToSharePoint();
      }
    }
    header.get('viewControlsButton').insertBefore(myCustomButton);
  });
});

window.addEventListener("message", receiveMessage, false);

function receiveMessage(event) {
  if (event.isTrusted && typeof event.data === 'object') {
    switch (event.data.type) {
      case 'OPEN_DOCUMENT':
        console.log(`${JSON.stringify(event.data)}`);
        instance.loadDocument(event.data.file)
        break;
      case 'OPEN_DOCUMENT_BLOB':
        const { blob, extension, filename, documentId } = event.data.payload;
        currentDocId = event.data.payload;

        // Check if the document is a .docx file
        if (extension === 'docx') {
          // If so, enable office editing
          instance.UI.loadDocument(blob, { 
            extension, 
            filename, 
            documentId, 
            enableOfficeEditing: false, 
          });
        } else {
          // For other file types, load normally
          instance.UI.loadDocument(blob, { 
            extension, 
            filename, 
            documentId,
            enableOfficeEditing: false,
          });
        };
        break;
      case 'DOCUMENT_SAVED':
        console.log(`${JSON.stringify(event.data)}`);
        instance.UI.openElements(['savedModal']);
        setTimeout(() => {
          instance.UI.closeElements(['savedModal', 'loadingModal'])
        }, 2000)
        break;
      case 'LMS_RECEIVED':  
        instance.loadDocument(event.data.payload.message, {
          filename: event.data.payload.filename,
          withCredentials: false
        });
        break;
      case 'FILL_TEMPLATE':
        fillDocument(event);
        break;
      case 'BULK_TEMPLATE':
        generateBulkDocument(event);
        break;
      case 'DOWNLOAD_DOCUMENT':
        downloadWebViewerFile();
        break;
      case 'CLOSE_DOCUMENT':
        instance.UI.closeDocument()
        currentDocId = null;
        break;
      default:
        break;
    }
  }
}