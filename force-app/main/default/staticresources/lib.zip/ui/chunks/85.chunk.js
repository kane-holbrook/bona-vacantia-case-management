(window.webpackJsonp=window.webpackJsonp||[]).push([[85],{1803:function(n,e,t){t(43)({target:"Number",stat:!0},{isInteger:t(561)})}}]);
//# sourceMappingURL=85.chunk.js.map